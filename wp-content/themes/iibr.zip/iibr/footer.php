<!--EDU2 FOOTER WRAP START-->
		<!--NEWS LETTERS START-->
		<div class="edu2_ft_topbar_wrap">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="edu2_ft_topbar_des">
							<h5>Subcribe weekly newsletter</h5>
						</div>
					</div>
					<div class="col-md-6">
						<div class="edu2_ft_topbar_des">
							<form>
								<input type="email" placeholder="Enter Valid Email Address">
								<button><i class="fa fa-paper-plane"></i>Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--NEWS LETTERS END-->
<!--FOOTER START-->
		<footer>
			<!--EDU2 FOOTER CONTANT WRAP START-->
				<div class="container">
					<div class="row">
						<!--EDU2 FOOTER CONTANT DES START-->
						<div class="col-md-3">
							<div class="widget widget-links">
								<h5>Information</h5>
								<ul>
									<li><a href="aboutus.html">About us</a></li>
									<li><a href="#">Programme</a></li>
									<li><a href="#">Campus</a></li>
									<li><a href="#">News & Events</a></li>
									<li><a href="#">Gallery</a></li>
                                    <li><a href="#">Contact Us</a></li>

                                </ul>
							</div>
						</div>
						<!--EDU2 FOOTER CONTANT DES END-->

						<!--EDU2 FOOTER CONTANT DES START-->
						<div class="col-md-3">
							<!-- <div class="widget widget-links">
								<h5>Student Help</h5>
								<ul>
									<li><a href="#">My Info</a></li>
									<li><a href="#">My Questions</a></li>
									<li><a href="#">F.A.Q</a></li>
									<li><a href="#">Serch Courses</a></li>
									<li><a href="#">Latest Informations</a></li>
								</ul>
							</div> -->
						</div>
						<!--EDU2 FOOTER CONTANT DES END-->

						<!--EDU2 FOOTER CONTANT DES START-->
						<div class="col-md-3">
							<!-- <div class="widget wiget-instagram">
								<h5>Instagram</h5>
								<ul>
									<li><a href="#"><img src="extra-images/instagram-1.jpg" alt=""/></a></li>
									<li><a href="#"><img src="extra-images/instagram-2.jpg" alt=""/></a></li>
									<li><a href="#"><img src="extra-images/instagram-3.jpg" alt=""/></a></li>
									<li><a href="#"><img src="extra-images/instagram-4.jpg" alt=""/></a></li>
									<li><a href="#"><img src="extra-images/instagram-5.jpg" alt=""/></a></li>
									<li><a href="#"><img src="extra-images/instagram-6.jpg" alt=""/></a></li>
								</ul>
							</div> -->
						</div>
						<!--EDU2 FOOTER CONTANT DES END-->

						<!--EDU2 FOOTER CONTANT DES START-->
						<div class="col-md-3">
							<div class="widget widget-contact">
								<h5>Contact</h5>




								<ul>

										<li>S. No. 29/1+2A, Near Empire Estate,
                                          Pune - Mumbai Highway, Pimpri, Pune - 411018 </li>
										<li>Phone<a href="#">+91-20-27478666, 66351700 </a></li>

										<li>Phone<a href="#">9422009207 / 09 / 10 / 12 </a></li>

										<li>Fax<a href="#"> +91-20-27471753</a></li>

										<li>Email<a href="#"> seattle@asmedu.org</a></li>


									<!-- <li>PO Box UN152468, 1 Street North, New Towm, California, USA</li>
									<li>Phone : <a href="#"> 5 (012) 4565 789</a></li>
									<li>Fax : <a href="#"> 5 (012) 4565 789</a></li>
									<li>Email : <a href="#"> Info@info.com</a></li> -->
								</ul>
							</div>
						</div>
						<!--EDU2 FOOTER CONTANT DES END-->
					</div>
				</div>
		</footer>
		<!--FOOTER END-->
		<!--COPYRIGHTS START-->
		<div class="edu2_copyright_wrap">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<div class="edu2_ft_logo_wrap">
							<a href="#"><img src="<?php echo bloginfo('template_url');?>/extra-images/logo_2.png" alt=""/></a>
						</div>
					</div>

					<div class="col-md-6">
						<div class="copyright_des">
							<span>&copy;  <a href="#">Designed at Kreativ Street</a></span>
						</div>
					</div>

					<div class="col-md-3">
						<!--<ul class="cards_wrap">-->
							<!--<li><a href="#"><img src="extra-images/visacard.png" alt=""/></a></li>-->
							<!--<li><a href="#"><img src="extra-images/mastercard.png" alt=""/></a></li>-->
							<!--<li><a href="#"><img src="extra-images/americancard.png" alt=""/></a></li>-->
							<!--<li><a href="#"><img src="extra-images/card.png" alt=""/></a></li>-->
							<!--<li><a href="#"><img src="extra-images/descoverycard.png" alt=""/></a></li>-->
						<!--</ul>-->
					</div>
				</div>
			</div>
		</div>
		<!--COPYRIGHTS START-->
    </div>
    <!--KF KODE WRAPPER WRAP END-->
	<!--Bootstrap core JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.js"></script>
	<script src="<?php echo bloginfo('template_url');?>/js/bootstrap.min.js"></script>
	<!--Bx-Slider JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.bxslider.min.js"></script>
	<!--Owl Carousel JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/owl.carousel.min.js"></script>
	<!--Pretty Photo JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.prettyPhoto.js"></script>
	<!--Full Calender JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/moment.min.js"></script>
	<script src="<?php echo bloginfo('template_url');?>/js/fullcalendar.min.js"></script>
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.downCount.js"></script>
	<!--Image Filterable JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery-filterable.js"></script>
	<!--Accordian JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.accordion.js"></script>
	<!--Number Count (Waypoints) JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/waypoints-min.js"></script>
	<!--v ticker-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.vticker.min.js"></script>
	<!--select menu-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.selectric.min.js"></script>
	<!--Side Menu-->
	<script src="<?php echo bloginfo('template_url');?>/js/jquery.sidr.min.js"></script>
	<!--Custom JavaScript-->
	<script src="<?php echo bloginfo('template_url');?>/js/custom.js"></script>


</body>
</html>
